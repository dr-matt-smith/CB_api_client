'''
import math - once a top of listings
    not in a function such as power()


'''


def add(num1, num2):
    n1 = float(num1)
    n2 = float(num2)
    return n1 + n2

def choice1():
    userinput = input("Enter two numbers separated by space: ").split()
    result = add(userinput[0], userinput[1])
    print("Result:", result)

def subtract(num1, num2):
    n1 = float(num1)
    n2 = float(num2)
    return n1 - n2

def choice2():
    userinput = input("Enter two numbers separated by space: ").split()
    result = subtract(userinput[0], userinput[1])
    print("Result:", result)

def multiply(num1, num2):
    n1 = float(num1)
    n2 = float(num2)
    return n1 * n2

def choice3():
    userinput = input("Enter two numbers separated by space: ").split()
    result = multiply(userinput[0], userinput[1])
    print("Result:", result)

def divide(num1, num2):
    n1 = float(num1)
    n2 = float(num2)
    return n1 // n2

def choice4():
    userinput = input("Enter two numbers separated by space: ").split()
    result = divide(userinput[0], userinput[1])
    print("Result:", result)

def squareroot(num1):
    import math
    n1 = float(num1)
    return math.sqrt(n1)

def choice5():
    userinput = int(input("Enter a number: "))
    result = squareroot(userinput)
    print("Result:", result)

def power(num1, num2):
    import math
    n1 = float(num1)
    n2 = float(num2)
    return math.pow(n1, n2)

def choice6():
    userinput = input("Enter the base and the exponent: ").split()
    result = power(userinput[0], userinput[1])
    print("Result:", result)

def logarithm(num1):
    import math
    n1 = float(num1)
    return math.log(n1)

def choice7():
    userinput = input("Enter a number: ").split()
    result = logarithm(userinput[0])
    print("Result:", result)

def menu_choice():
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Division") #float
    print("5. Square Root") #math module
    print("6. Power") #math module
    print("7. Logarithm") #default, math module
    print("8. Exit")
    choiceinput = input("Select an operation: ")
    return choiceinput

while True:
    choiceinput = menu_choice()
    if choiceinput == "1":
        choice1()
    elif choiceinput == "2":
        choice2()
    elif choiceinput == "3":
        choice3()
    elif choiceinput == "4":
        choice4()
    elif choiceinput == "5":
        choice5()
    elif choiceinput == "6":
        choice6()
    elif choiceinput == "7":
        choice7()
    elif choiceinput == "8":
        print("exiting the calculator...")
        break
    else:
        print("Invalid input, please try again")
        continue


